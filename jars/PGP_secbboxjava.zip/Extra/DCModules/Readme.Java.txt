This folder contains sources of the applet that can be used to sign data remotely.
The user is able to use Windows system certificate storage, cryptographic tokens 
and smart cards which provide PKCS#11 drivers, and X.509 certificates loaded from 
a Java Key Store file (*.jks) or from a PFX-file (*.pfx, *.p12).

The applet can be compiled with JDK 5 and later. Please note that if there is 
only JRE 5 available on the client computer, the applet will not use 
Windows system certificate storage which is supported since JRE 6 only.

The applet can be embedded into a HTML page using the following code:

<applet archive="com.secureblackbox.dc.jar, com.secureblackbox.dc.applet.jar" 
    code="com.secureblackbox.dc.applet.ElDCServerApplet" width=500 height=240>
    <param name="Color" value="color value in form #RRGGBB" />
    <param name="DataURL" value="absolute or relative url" />
    <param name="GoURL" value="absolute or relative url" />
    <param name="AllowWindowsStorage" value="false|true|no|yes" />
    <param name="AllowFileStorage" value="false|true|no|yes" />
    <param name="AllowTokenStorage" value="false|true|no|yes" />
    <param name="Token" value="token name" />
    <param name="Data" value="base64-encoded xml request" />
    <param name="SessionID" value="unique text" />
</applet>

Supported parameters

1. SessionID

   A string that will be added to a query string of the answers.
   
2. Data
   
   Base64-encoded XML document produced by the ElDCAsyncState class.
   
3. DataURL (optional)

   URL that should be used to POST the resulting signature to; the resulting data 
   is in form of XML and posted with application/xml Content-Type field specified.
   Query part of URL is allowed, sessionid parameter will be added to it 
   automatically; if DataURL parameter is not specified, the resulting signature 
   is sent using GET request to the URL specified in GoURL parameter.
   
4. GoURL (optional)

   URL that should be used to navigate the browser and (if DataURL not specified) 
   return the resulting data. Query part of URL is allowed, SessionID parameter 
   will be added to it automatically; if DataURL parameter is not specified, the 
   resulting signature will be added to the query as data parameter using base64 
   encoding. If GoURL parameter is not specified, the browser will remain on the 
   applet page.

5. AllowFileStorage (optional)

   Specifies if the user is allowed to use keys loaded from files. Possible
   values are: "true" or "yes" to allow the user to load keys from files, and
   "false" or "no" to disable this. If the parameter is not specified, the default
   value is "yes".

6. AllowWindowsStorage (optional)

   Specifies if the user is allowed to use keys from the Windows system 
   certificate storage. Possible values are: "true" or "yes" to allow the user 
   to use keys from Windows certificate storage, and "false" or "no" to disable 
   this. If the parameter is not specified, the default value is "yes".
 
7. AllowTokenStorage (optional)

   Specifies if the user is allowed to use keys from security tokens and/or
   smart cards. Possible values are: "true" or "yes" to allow the user to use 
   keys from security tokens and/or smart card, and "false" or "no" to disable 
   this. If the parameter is not specified, the default value is "yes".
 
8. Token (optional) 

   Name of token that must be used to sign the data. If the parameter is not 
   specified, the user will be prompted to select a token from the list of
   registered tokens in his/her JRE. If the parameter is specified but there is no 
   provider with name SunPKCS11-<token name> (w/o brackets) registered in the JRE,
   the user will not be able to use crypto tokens at all.
   If the parameter AllowTokenStorage is set to "false" or "no", value of the
   Token parameter makes no sense.
   
9. Color

   Background color of the applet in HTML style: #RRGGBB. If the parameter is not 
   specified the applet is going to use WHITE color.
   
10. Width

   The applet is designed to be 500px width.
   
11. Height

   The applet is designed to be 240px height
   
Support for different key and certificate storages.
 
1. Windows certificate storage

   If the applet is running on Windows platform and there is at least one 
   certificate with private key exist in that storage, then the option will be 
   enabled. On all other platforms or if there is no certificate with private key 
   in the storage, the option will be disabled.
   
2. Cryptographic tokens and smart cards using PKCS#11

   To use such a device, it must be registered in JRE on the client computer. On 
   instructions how to do this please see the guide at
   http://download.oracle.com/javase/1.5.0/docs/guide/security/p11guide.html#Config
   On start the applet looks for all providers which names	start with SunPKCS11-. 
   If no such providers found, the option will not be available. You're able to 
   force the user to use certain device by specifying its name in Token parameter 
   of the applet (see the description of the parameter above). You also can disable 
   to use such devices by specifying a unique token name that cannot be found on any 
   client computer. 
   
3. Java key storages and PKCS#12 (pfx, p12) files

   This option does no require any configuration on the user side.
