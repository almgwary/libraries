This folder contains sources of the Flex control that can be used to sign data
remotely. The user is able to use X.509 certificates stored in .CER and .PEM files.

The control can be embedded into a HTML page using the following script:

    <script type="text/javascript">
        function embed() {
            flashembed("flashContent",
                {
                    src: "com.secureblackbox.dc.signer.swf",
                    allowfullscreen: false,
                    allowscriptaccess: false,
                    cachebusting: true,
                    width: 500,
                    height: 500,
                    version: [10, 0]
                }, {
                    DataURL: "relative url",
                    GoURL: "absolute or relative url",
                    SessionID: "unique text",
                    Data: "base64-encoded xml request"
                }
            );
        }
    </script>

This script replaces the content of an html-element with id "flashContent" with 
embedding code. The script uses the function flashembed which is described at
http://www.jquerytools.org/documentation/toolbox/flashembed.html

IMPORTANT!!! All parameters of the flex control MUST be url-encoded.

Supported parameters

1. SessionID

   A string that will be added when posting the signed data back to the server and 
   navigating the browser after the data is signed. If DataURL parameter is specified
   the signed data is transferred to the server from within the control, the browser 
   is not used for this purpose. And this value is the only way to determine the 
   corresponding signing session on the server.

2. Data

   Base64-encoded XML document produced by ElDCAsyncState class

3. DataURL (optional)

   URL that will be used to POST the resulting signature to; the resulting data is 
   in form of XML and is posted with application/xml Content-Type field set. Query 
   part of URL is allowed, SessionID parameter will be added to it automatically.
   If DataURL parameter is not specified, the resulting	signature is sent using 
   query part of GET request to the URL specified in GoURL parameter. Both
   absolute and relative urls are supported in this parameter.

4. GoURL (optional)

   URL that will be used to navigate the browser and (if DataURL not specified) 
   return the resulting data. Query part of URL is allowed, SessionID parameter 
   will be added to it automatically. If DataURL parameter is not specified, the 
   resulting signature will be added to the query as Data parameter using base64 
   encoding. If GoURL parameter is not specified, the browser will remain on the 
   page which contains the control. Both absolute and relative urls are supported
   in this parameter.
