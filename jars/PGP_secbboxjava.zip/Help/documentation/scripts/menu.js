jQuery.noConflict();
(function ($) {

	$(document).ready(function () {
		
		if ($("#menu").length > 0) {
			$("#menu").InitTreeMenu();
			$("#menu ul li > span").bind("click", function () {
				$(this).parent().toggleClass("collapsed");
				$(this).parent().find("ul:first").slideToggle();
			});	
		} else {
			$( ".doc-menu nav" ).load( "toc_part.html", function( result ) {
				if (result) {
					$("#menu").InitTreeMenu();
					$("#menu ul li > span").bind("click", function () {
						$(this).parent().toggleClass("collapsed");
						$(this).parent().find("ul:first").slideToggle();
					});
				}
			});
		}
	});
	
	
	$.fn.InitTreeMenu = function () {
		var p = window.location.pathname.split( '/' );
		$(this).find("ul li > ul").hide();
		$(this).find("ul li").addClass("collapsed")
		$("a[href='" + p[p.length - 1] + "']").addClass("active");
		$("a[href='" + p[p.length - 1] + "']").parents("ul, li, ul:not(#menu)").show();
		$("a[href='" + p[p.length - 1] + "']").parents("li").removeClass("collapsed");
	}
	
})(jQuery);