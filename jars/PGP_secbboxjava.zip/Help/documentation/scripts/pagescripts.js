jQuery.noConflict();
		(function($) {

			$(document).ready(function(){



				$("div[group]").each(function() {
					
					var groupRefAttr = $(this).attr("group");
					var visibilityState = $.cookie(groupRefAttr);

					if (visibilityState == null){ visibilityState = 1; $.cookie(groupRefAttr, 1, { expires: 365 }); }
					if (visibilityState == 1 || visibilityState == "1"){ $(this).show(); }
					else if (visibilityState == 0 || visibilityState == "0"){ $(this).hide(); }

				});

				$(window).scroll(function() {

					if ($(this).scrollTop()) { $('#back-to-top').fadeIn(); }
					else { $('#back-to-top').fadeOut(); }

				});

				$("#back-to-top").click(function () {
					$("html, body").animate(scrollToAnchor('top'), 1000);
				});

				$("img").hover(function() {
					var OnMouseOverAttr = $(this).attr("onmouseover");
					var BlockNameAttr = $(this).attr("blockname");
					if (BlockNameAttr && OnMouseOverAttr){
						position = $(this).position();
						$(this).after("<div id='tooltip'></div>");
						$("#"+BlockNameAttr).clone().appendTo("#tooltip");
						$("#tooltip #"+BlockNameAttr).show();
						$("#tooltip #"+BlockNameAttr).css("visibility", "visible");
						$("#tooltip").css("left", position.left + 5);
						$("#tooltip").css("top", position.top + 10);
					}
					},function () {
						$("#tooltip").remove();
					}
					
				);

				$("a").click(function() {
					var BlockNameAttr = $(this).attr("blockname");
					var groupRefAttr = $(this).attr("groupref");
					if (BlockNameAttr){
   						position = $(this).position();
						$(this).after("<div id='tooltip'></div>");
						$("#"+BlockNameAttr).clone().appendTo("#tooltip");
						$("#tooltip #"+BlockNameAttr).show();
						$("#tooltip").css("left", position.left - 6);
						$("#tooltip").css("top", position.top + 18);
					}
					if (groupRefAttr){
						visibilityState = $.cookie(groupRefAttr);
						if (visibilityState == null) { 
							$("div[group='"+groupRefAttr+"']" ).toggle();
						} else 
						if (visibilityState == 1 || visibilityState == "1"){
							$("div[group='"+groupRefAttr+"']" ).hide();
							$.cookie(groupRefAttr, 0, { expires: 365 });
						} else
						if  (visibilityState == 0 || visibilityState == "0"){
							$("div[group='"+groupRefAttr+"']" ).show();
							$.cookie(groupRefAttr, 1, { expires: 365 });
						}
					}
				});
				

				$(document).mouseup(function (e){
				    var container = $("#tooltip");
				
				    if (!container.is(e.target)
				        && container.has(e.target).length === 0)
				    {
				        container.remove();
				    }
				});

			});

		})(jQuery);

